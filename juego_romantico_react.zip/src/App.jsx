import { useState } from 'react';
import './App.css';

function App() {
  const [scene, setScene] = useState('start');

  const handleChoice = (choice) => {
    if (choice === 'talk') setScene('talk');
    else if (choice === 'song') setScene('song');
    else setScene('end');
  };

  return (
    <div className="app">
      {scene === 'start' && (
        <div className="scene">
          <h1>Hola, este es un pequeño regalo para ti 💖</h1>
          <button onClick={() => handleChoice('talk')}>Hablar con él</button>
          <button onClick={() => handleChoice('song')}>Escuchar una canción</button>
          <button onClick={() => handleChoice('end')}>Ir al final</button>
        </div>
      )}

      {scene === 'talk' && (
        <div className="scene">
          <h2>Él te dice: “Siempre me alegra hablar contigo.”</h2>
          <button onClick={() => setScene('start')}>Volver</button>
        </div>
      )}

      {scene === 'song' && (
        <div className="scene">
          <h2>Está sonando su canción favorita contigo 🎵</h2>
          <audio controls autoPlay>
            <source src="/song.mp3" type="audio/mpeg" />
            Tu navegador no soporta audio.
          </audio>
          <button onClick={() => setScene('start')}>Volver</button>
        </div>
      )}

      {scene === 'end' && (
        <div className="scene">
          <h2>Gracias por estar aquí 💌</h2>
          <p>Este es solo un pequeño regalo, pero viene con mucho cariño.</p>
        </div>
      )}
    </div>
  );
}

export default App;
